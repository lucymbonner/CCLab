#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    
    xPos = 31;
    xVel = 5;
    xDirection = 1;

}

//--------------------------------------------------------------
void ofApp::update(){
    
    xPos = xPos + (xVel * xDirection);
    
    if (xPos > (ofGetWidth()-30) || xPos < 30) {
        xDirection *= -1;
    }

}

//--------------------------------------------------------------
void ofApp::draw(){
    
    ofBackground(0, 0, 0);
    
    ofSetColor(ofRandom(255), ofRandom(255), ofRandom(255));
    ofFill();
    ofCircle(xPos, 200, 30);

}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
