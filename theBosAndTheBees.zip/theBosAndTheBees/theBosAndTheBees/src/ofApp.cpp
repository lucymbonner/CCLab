#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    ofBackground(0, 209, 202);
    
    for (int i = 0; i < NUMBEES; i++) {
        bee[i].setup();
    }
    
    //set up grid of Bos
    
    fieldHeight = ofGetHeight();
    fieldWidth  = ofGetWidth();
    resolution = 95; //space between the Bos
    
}

//--------------------------------------------------------------
void ofApp::update(){
    
    angle = sin(ofGetElapsedTimef()*5);
    
    //rotate all the BoFaces, then move all the bees
    
    for (int i = 0; i < NUMBOS; i++) {
        boFaces[i].angle = sin(ofGetElapsedTimef()*i);
    }
    
    for (int i = 0; i < NUMBEES; i++) {
        bee[i].move();
    }
    
}

//--------------------------------------------------------------
void ofApp::draw(){
    
    //    display Bos and Bees
    
    for (int i = 0; i < NUMBOS; i++) {
        boFaces[i].display();
    }
    
    for (int i = 0; i < NUMBEES; i++) {
        bee[i].display();
    }
    
    //instructions in corner
    
    ofSetColor(255);
    ofDrawBitmapString("Click to have some fun with Bo.", 30, 30);
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){
    
}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){
    
}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
    
    //for loop recreating bees at mouse click point
    
        for (int i = 0; i < NUMBEES; i++) {
            bee[i].reset(mouseX, mouseY);
        }
    
    //making the grid of Bos appear when you click
    
    int columns = fieldWidth / resolution;
    int rows = fieldHeight / resolution;
    
    for (int i = 0; i < NUMBOS; i++) {
        ofPushMatrix();
        posX = i % columns * resolution;
        posY = i / columns * resolution;
        ofTranslate(posX, posY);
        boFaces[i].setup();
        boFaces[i].grid(posX, posY);
        ofPopMatrix();
    }
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){
    
}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){
    
}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 
    
}
