//
//  theBosAndTheBees.cpp
//  animationIsCool
//
//  Created by Lucy M Bonner on 11/3/14.
//
//

#include "theBosAndTheBees.h"

//class of Bos!

Bo::Bo() {
    angle = 0;
    boVelocity = 5;
    
    posX = 20;
    posY = 20;
}

void Bo::setup() {
    
    BoFace.loadImage("bo_head_2.png");

}

void Bo::move() {
    
    //Bos will rotate on a sine curve, and more vigorously as they get further from the origin point
    
    angle = sin(ofGetElapsedTimef()*2);

}

void Bo::display() {
    
    //rotating each Bo face from its center
    
    ofPushMatrix();
    ofTranslate(posX, posY);
    ofRotate(angle);
    ofSetRectMode(OF_RECTMODE_CENTER);
    BoFace.draw(posX, posY);
    ofPopMatrix();
}

void Bo::grid(int newPosX, int newPosY) {
    
    //creating grid based on each Bo's center point
    
    ofPushMatrix();
    posX = newPosX;
    posY = newPosY;
    ofTranslate(posX, posY);
    ofSetRectMode(OF_RECTMODE_CENTER);
    ofPopMatrix();
}




