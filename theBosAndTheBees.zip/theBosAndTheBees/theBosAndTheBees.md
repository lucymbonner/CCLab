# The Bos and the Bees

> The Bos & the Bees is an openFrameworks project by Lucy M Bonner. 

A play on the euphamism "the birds and the bees" with my delightful dog Bo as an adorably wiggly substitute. As the user clicks on the screen, Bo faces appear in a grid, wiggle on a sine curve from the upper corner, and the bees regenerate to bouce around. Fun all round!

  - Vectors are cool
  - openGL
  - Magic.. or math.

I used the CC Lab class walrus code as the basis for the bee movement, and the wonderful Barbara Compagnoni helped me work out the bugs in the grid wiggles.

I would like to add music that the Bos can wiggle in time to, and put this on the web as a fun little website to play with. Much like dancing cats. 

> Frankly I'm just glad I could get anything working and in a named file with all the trouble I've been having getting openFrameworks and Xcode to work on my computer. Woo.


**Free Software, Hell Yeah!**

[john gruber]:http://daringfireball.net/
[@thomasfuchs]:http://twitter.com/thomasfuchs
[1]:http://daringfireball.net/projects/markdown/
[marked]:https://github.com/chjj/marked
[Ace Editor]:http://ace.ajax.org
[node.js]:http://nodejs.org
[Twitter Bootstrap]:http://twitter.github.com/bootstrap/
[keymaster.js]:https://github.com/madrobby/keymaster
[jQuery]:http://jquery.com
[@tjholowaychuk]:http://twitter.com/tjholowaychuk
[express]:http://expressjs.com
[AngularJS]:http://angularjs.org
[Gulp]:http://gulpjs.com
