//
//  theBosAndTheBees.cpp
//  animationIsCool
//
//  Created by Lucy M Bonner on 11/3/14.
//
//

#include "theBosAndTheBees.h"

Bo::Bo() {
    
    
    posX = 20;
    posY = 20;
}

void Bo::setup() {
    
    BoFace.loadImage("bo_head_2.png");

}

void Bo::move() {
    ofPushMatrix();
    ofTranslate(posX+50, posY+71);
    ofRotate(45);
    ofPopMatrix();
    
    
//    ofPushMatrix();
//        ofTranslate(posX+50, posY+71, 0);//move pivot to centre
//        ofRotate(45, 0, 0, 1);//rotate from centre
////        ofPushMatrix();
////            ofTranslate(-(posX+50),-(posY+71),0);//move back by the centre offset
////            BoFace.draw(0,0);
////        ofPopMatrix();
//    ofPopMatrix();
}

void Bo::display() {
    BoFace.draw(posX, posY);
}

void Bo::grid(int newPosX, int newPosY) {
    posX = newPosX;
    posY = newPosY;
}