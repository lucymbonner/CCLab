#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    ofBackground(0, 209, 202);
    
//    oneBo.setup();
    
    for (int i = 0; i < NUMBOS; i++) {
        boFaces[i].setup();
    }

    for (int i = 0; i < NUMBEES; i++) {
        bee[i].setup();
    }

}

//--------------------------------------------------------------
void ofApp::update(){
    
//    oneBo.move();
    
    //rotate all the BoFaces, then move all the bees
    
    for (int i = 0; i < NUMBOS; i++) {
        boFaces[i].move();
    }
    
    for (int i = 0; i < NUMBOS; i++) {
        bee[i].move();
    }

}

//--------------------------------------------------------------
void ofApp::draw(){
    
//    oneBo.display();
    
    for (int i = 0; i < NUMBOS; i++) {
        boFaces[i].display();
    }
    
    for (int i = 0; i < NUMBOS; i++) {
        bee[i].display();
    }
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
    
    for (int i = 0; i < NUMBEES; i++) {
        bee[i].reset(mouseX, mouseY);
    }
    int posX = 20;
    int posY = 20;
    for (int i = 0; i < NUMBOS; i++) {
        boFaces[i].grid(posX, posY);
        if (i > 40) {
            posY = 600;
            posX += 100;
        } else if (i > 30) {
            posY = 450;
            posX += 100;
        } else if (i > 20) {
            posY = 300;
            posX += 100;
        } else if (i > 10) {
            posY = 150;
            posX += 100;
        } else if (i < 10) {
            posY = 20;
            posX += 100;
        }
    }

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
